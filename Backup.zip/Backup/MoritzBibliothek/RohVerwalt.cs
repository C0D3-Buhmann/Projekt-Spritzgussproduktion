﻿using System.Windows.Forms;

namespace MoritzBibliothek
{
    public partial class RohVerwalt : Form
    {
        public RohVerwalt()
        {
            InitializeComponent();
        }
    }
}