﻿using System.Windows.Forms;

namespace MoritzBibliothek
{
    public partial class ProdVerwalt : Form
    {
        public ProdVerwalt()
        {
            InitializeComponent();
        }
    }
}