﻿using System.Windows.Forms;

namespace Projekt_Spritzgussproduktion
{
    public partial class test : UserControl
    {
        public test()
        {
            InitializeComponent();
        }
    }
}