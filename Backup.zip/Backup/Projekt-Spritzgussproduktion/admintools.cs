﻿using System.Windows.Forms;

namespace Projekt_Spritzgussproduktion
{
    public partial class admintools : Form
    {
        public admintools()
        {
            InitializeComponent();
        }
    }
}