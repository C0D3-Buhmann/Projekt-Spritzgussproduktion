﻿using System.Windows.Forms;

namespace Projekt_Spritzgussproduktion
{
    public partial class Lieferschein : Form
    {
        public Lieferschein()
        {
            InitializeComponent();
        }
    }
}