﻿using System.Windows.Forms;

namespace Projekt_Spritzgussproduktion
{
    public partial class AufträgeÜbersicht : Form
    {
        public AufträgeÜbersicht()
        {
            InitializeComponent();
        }
    }
}