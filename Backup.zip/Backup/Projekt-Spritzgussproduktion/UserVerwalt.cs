﻿using System.Windows.Forms;

namespace Projekt_Spritzgussproduktion
{
    public partial class UserVerwalt : Form
    {
        public UserVerwalt()
        {
            InitializeComponent();
        }
    }
}